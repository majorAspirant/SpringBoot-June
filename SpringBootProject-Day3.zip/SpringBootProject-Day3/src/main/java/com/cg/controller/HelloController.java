package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.pojos.Employee;


@Controller
public class HelloController {
	
	@RequestMapping("/hi")
	public ModelAndView sayHello(){
		return new ModelAndView("hello","msg","Nameee");
	}
	
	@RequestMapping("/showEmployee")
	public ModelAndView showEmployee() {
		//emp is mapped to the commandName of the jsp page
		return new ModelAndView("showEmployee","emp",new Employee()); 
	}
	
	@RequestMapping(value="/saveEmployee", method=RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute("emp") Employee employee){
		System.out.println("Inside Save Employee");
		return new ModelAndView ("employeeDetails");
	}
}
