package com.cg.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.cg"})
public class SpringBootProjectDay3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectDay3Application.class, args);
	}
}
