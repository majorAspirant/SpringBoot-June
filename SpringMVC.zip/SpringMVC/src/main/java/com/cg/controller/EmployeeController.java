package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.pojos.Employee;

@Controller
public class EmployeeController {
	
	@RequestMapping(value="/populatePage")
	public ModelAndView populateForm(){
		//create empty form
		return new ModelAndView("addEmployeeForm","employeeModel", new Employee());
	}
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public String addEmployee(@ModelAttribute("employeeModel") Employee employee, BindingResult result, Model model){
		System.out.println("Inside addEmployee() ");
		Employee employeeModel = new Employee();
		employeeModel.setFirstName(employee.getFirstName());
		employeeModel.setLastName(employee.getLastName());
		employeeModel.setEmpDOB(employee.getEmpDOB());
		employeeModel.setEmpDOJ(employee.getEmpDOJ());
		employeeModel.setEmail(employee.getEmpId());
		model.addAttribute(employeeModel);
		return "employeeDetails";
	}
	
/*	@RequestMapping(value="/showEmployeeDetails", method=RequestMethod.POST)
	public String showEmployeeDetails( ){
		
		return "employeeDetails";
	}*/

}
